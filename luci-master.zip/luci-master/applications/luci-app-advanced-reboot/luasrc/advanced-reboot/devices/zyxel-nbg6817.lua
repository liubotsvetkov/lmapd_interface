return {
	vendorName = "ZyXEL",
	deviceName = "NBG6817",
	boardName = "nbg6817",
	partition1MTD = "mmcblk0p4",
	partition2MTD = "mmcblk0p7",
	labelOffset = 32,
	bootEnv1 = nil,
	bootEnv1Partition1Value = 255,
	bootEnv1Partition2Value = 1,
	bootEnv2 = nil,
	bootEnv2Partition1Value = nil,
	bootEnv2Partition2Value = nil
}
